--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.0
-- Dumped by pg_dump version 13.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "PCS";
--
-- Name: PCS; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "PCS" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Singapore.1252';


ALTER DATABASE "PCS" OWNER TO postgres;

\connect "PCS"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appliedleave; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appliedleave (
    emailaddr character varying(1000) NOT NULL,
    startdate date NOT NULL,
    enddate date NOT NULL,
    leavetype character varying(1000),
    accepted character(1),
    CONSTRAINT chk_endlaterthanstart CHECK ((enddate >= startdate))
);


ALTER TABLE public.appliedleave OWNER TO postgres;

--
-- Name: availability; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.availability (
    emailaddr character varying(1000) NOT NULL,
    servicetype character varying(1000) NOT NULL,
    servicedescription character varying(1000),
    dailyprice integer,
    totalcost integer NOT NULL,
    petslotsleft integer NOT NULL,
    startdate date NOT NULL,
    enddate date NOT NULL,
    CONSTRAINT chk_servicedescription CHECK (((servicedescription)::text = ANY ((ARRAY['Boarding'::character varying, 'DayCare'::character varying])::text[])))
);


ALTER TABLE public.availability OWNER TO postgres;

--
-- Name: basedailyprice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.basedailyprice (
    emailaddr character varying(1000) NOT NULL,
    pettype character varying(1000) NOT NULL,
    price integer,
    CONSTRAINT chk_pettype CHECK (((pettype)::text = ANY ((ARRAY['Cat'::character varying, 'Dog'::character varying, 'Rabbit'::character varying])::text[])))
);


ALTER TABLE public.basedailyprice OWNER TO postgres;

--
-- Name: bids; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bids (
    rating numeric(2,1),
    review character varying(1000),
    transportmethod integer,
    success integer,
    paymenttype character varying(1000),
    poemail character varying(1000) NOT NULL,
    petname character varying(1000) NOT NULL,
    ctemail character varying(1000) NOT NULL,
    servicetype character varying(1000),
    totalcost integer,
    startdate date NOT NULL,
    enddate date NOT NULL,
    petslotsleft integer
);


ALTER TABLE public.bids OWNER TO postgres;

--
-- Name: caretaker; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.caretaker (
    emailaddr character varying(1000) NOT NULL,
    avgrating numeric(2,1),
    petdays integer,
    availleave integer,
    employmenttype integer,
    basesalary numeric(7,2)
);


ALTER TABLE public.caretaker OWNER TO postgres;

--
-- Name: owns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.owns (
    emailaddr character varying(1000) NOT NULL,
    petname character varying(1000) NOT NULL,
    pettype character varying(1000),
    breed character varying(1000),
    weight numeric(5,2),
    sex character(1),
    specialrequirements text,
    petbirthday date
);


ALTER TABLE public.owns OWNER TO postgres;

--
-- Name: pcsadmin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pcsadmin (
    adminemailaddr character varying(1000) NOT NULL,
    pcsadminpass character varying(10000)
);


ALTER TABLE public.pcsadmin OWNER TO postgres;

--
-- Name: pcsuser; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pcsuser (
    emailaddr character varying(1000) NOT NULL,
    pcspass character varying(10000) NOT NULL,
    firstname character varying(1000),
    lastname character varying(1000),
    dob date,
    homeaddr character varying(1000),
    postalcode integer
);


ALTER TABLE public.pcsuser OWNER TO postgres;

--
-- Name: petowner; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petowner (
    emailaddr character varying(1000) NOT NULL,
    creditcardnum integer,
    creditcardcvc integer,
    creditcardexpirydate character varying(1000)
);


ALTER TABLE public.petowner OWNER TO postgres;

--
-- Data for Name: appliedleave; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appliedleave (emailaddr, startdate, enddate, leavetype, accepted) FROM stdin;
\.
COPY public.appliedleave (emailaddr, startdate, enddate, leavetype, accepted) FROM '$$PATH$$/3052.dat';

--
-- Data for Name: availability; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.availability (emailaddr, servicetype, servicedescription, dailyprice, totalcost, petslotsleft, startdate, enddate) FROM stdin;
\.
COPY public.availability (emailaddr, servicetype, servicedescription, dailyprice, totalcost, petslotsleft, startdate, enddate) FROM '$$PATH$$/3054.dat';

--
-- Data for Name: basedailyprice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.basedailyprice (emailaddr, pettype, price) FROM stdin;
\.
COPY public.basedailyprice (emailaddr, pettype, price) FROM '$$PATH$$/3051.dat';

--
-- Data for Name: bids; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bids (rating, review, transportmethod, success, paymenttype, poemail, petname, ctemail, servicetype, totalcost, startdate, enddate, petslotsleft) FROM stdin;
\.
COPY public.bids (rating, review, transportmethod, success, paymenttype, poemail, petname, ctemail, servicetype, totalcost, startdate, enddate, petslotsleft) FROM '$$PATH$$/3056.dat';

--
-- Data for Name: caretaker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.caretaker (emailaddr, avgrating, petdays, availleave, employmenttype, basesalary) FROM stdin;
\.
COPY public.caretaker (emailaddr, avgrating, petdays, availleave, employmenttype, basesalary) FROM '$$PATH$$/3050.dat';

--
-- Data for Name: owns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.owns (emailaddr, petname, pettype, breed, weight, sex, specialrequirements, petbirthday) FROM stdin;
\.
COPY public.owns (emailaddr, petname, pettype, breed, weight, sex, specialrequirements, petbirthday) FROM '$$PATH$$/3053.dat';

--
-- Data for Name: pcsadmin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pcsadmin (adminemailaddr, pcsadminpass) FROM stdin;
\.
COPY public.pcsadmin (adminemailaddr, pcsadminpass) FROM '$$PATH$$/3055.dat';

--
-- Data for Name: pcsuser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pcsuser (emailaddr, pcspass, firstname, lastname, dob, homeaddr, postalcode) FROM stdin;
\.
COPY public.pcsuser (emailaddr, pcspass, firstname, lastname, dob, homeaddr, postalcode) FROM '$$PATH$$/3048.dat';

--
-- Data for Name: petowner; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petowner (emailaddr, creditcardnum, creditcardcvc, creditcardexpirydate) FROM stdin;
\.
COPY public.petowner (emailaddr, creditcardnum, creditcardcvc, creditcardexpirydate) FROM '$$PATH$$/3049.dat';

--
-- Name: appliedleave appliedleave_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appliedleave
    ADD CONSTRAINT appliedleave_pkey PRIMARY KEY (emailaddr, startdate, enddate);


--
-- Name: availability availability_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.availability
    ADD CONSTRAINT availability_pkey PRIMARY KEY (emailaddr, startdate, enddate, petslotsleft, servicetype, totalcost);


--
-- Name: basedailyprice basedailyprice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.basedailyprice
    ADD CONSTRAINT basedailyprice_pkey PRIMARY KEY (emailaddr, pettype);


--
-- Name: bids bids_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_pkey PRIMARY KEY (poemail, ctemail, startdate, enddate, petname);


--
-- Name: caretaker caretaker_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caretaker
    ADD CONSTRAINT caretaker_pkey PRIMARY KEY (emailaddr);


--
-- Name: owns owns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.owns
    ADD CONSTRAINT owns_pkey PRIMARY KEY (emailaddr, petname);


--
-- Name: pcsadmin pcsadmin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pcsadmin
    ADD CONSTRAINT pcsadmin_pkey PRIMARY KEY (adminemailaddr);


--
-- Name: pcsuser pcsuser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pcsuser
    ADD CONSTRAINT pcsuser_pkey PRIMARY KEY (emailaddr);


--
-- Name: petowner petowner_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petowner
    ADD CONSTRAINT petowner_pkey PRIMARY KEY (emailaddr);


--
-- Name: appliedleave appliedleave_emailaddr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appliedleave
    ADD CONSTRAINT appliedleave_emailaddr_fkey FOREIGN KEY (emailaddr) REFERENCES public.caretaker(emailaddr);


--
-- Name: availability availability_emailaddr_servicetype_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.availability
    ADD CONSTRAINT availability_emailaddr_servicetype_fkey FOREIGN KEY (emailaddr, servicetype) REFERENCES public.basedailyprice(emailaddr, pettype);


--
-- Name: basedailyprice basedailyprice_emailaddr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.basedailyprice
    ADD CONSTRAINT basedailyprice_emailaddr_fkey FOREIGN KEY (emailaddr) REFERENCES public.caretaker(emailaddr);


--
-- Name: bids bids_ctemail_startdate_enddate_servicetype_totalcost_petsl_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_ctemail_startdate_enddate_servicetype_totalcost_petsl_fkey FOREIGN KEY (ctemail, startdate, enddate, servicetype, totalcost, petslotsleft) REFERENCES public.availability(emailaddr, startdate, enddate, servicetype, totalcost, petslotsleft) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bids bids_poemail_petname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_poemail_petname_fkey FOREIGN KEY (poemail, petname) REFERENCES public.owns(emailaddr, petname);


--
-- Name: caretaker caretaker_emailaddr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.caretaker
    ADD CONSTRAINT caretaker_emailaddr_fkey FOREIGN KEY (emailaddr) REFERENCES public.pcsuser(emailaddr);


--
-- Name: owns owns_emailaddr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.owns
    ADD CONSTRAINT owns_emailaddr_fkey FOREIGN KEY (emailaddr) REFERENCES public.petowner(emailaddr);


--
-- Name: petowner petowner_emailaddr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petowner
    ADD CONSTRAINT petowner_emailaddr_fkey FOREIGN KEY (emailaddr) REFERENCES public.pcsuser(emailaddr);


--
-- PostgreSQL database dump complete
--

